# Especificación: Gestión de costos de vehículos

## Objetivo
Registrar vehículos y gastos para consultar el dinero pagado por mes y año.

## Requisitos
- Registrar un vehículo con placa, marca, modelo, año y kilometraje.
- Registrar 14 categorías de gastos: seguro, marbete, revista, préstamo, depreciación, impuestos y permisos, parqueo mensual, combustible, mantenimiento, neumáticos, aceite, reparaciones, estacionamiento por horas y lavado.
- Clasificar los gastos en fijos y variables.
- Consultar, editar el monto y la descripción, y eliminar gastos.
- Mostrar totales por mes y año, y dividir el total anual entre los kilómetros recorridos.
- Guardar los datos en un archivo JSON.

## Limitaciones de la versión de aprendizaje
- Los gastos se anotan cuando ocurren; no se repiten automáticamente.
- La depreciación se introduce manualmente.
- No hay interfaz gráfica ni autenticación.
