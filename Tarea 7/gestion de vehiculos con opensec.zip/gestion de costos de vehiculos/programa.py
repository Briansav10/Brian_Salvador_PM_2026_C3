# Proyecto: Gestion de costos de vehiculos
# Programa basico para practicar variables, listas, funciones y condicionales.
import json
import os
from datetime import date

ARCHIVO = 'datos.json'
CATEGORIAS = {
    '1': ('Seguro', 'Fijo'), '2': ('Marbete', 'Fijo'),
    '3': ('Revista vehicular', 'Fijo'), '4': ('Prestamo', 'Fijo'),
    '5': ('Depreciacion', 'Fijo'), '6': ('Impuestos y permisos', 'Fijo'),
    '7': ('Parqueo mensual', 'Fijo'), '8': ('Combustible', 'Variable'),
    '9': ('Mantenimiento', 'Variable'), '10': ('Neumaticos', 'Variable'),
    '11': ('Aceite', 'Variable'), '12': ('Reparaciones', 'Variable'),
    '13': ('Estacionamiento por horas', 'Variable'), '14': ('Lavado', 'Variable')
}

def cargar():
    if os.path.exists(ARCHIVO):
        with open(ARCHIVO, 'r', encoding='utf-8') as archivo:
            return json.load(archivo)
    return {'vehiculos': [], 'gastos': []}

def guardar(datos):
    with open(ARCHIVO, 'w', encoding='utf-8') as archivo:
        json.dump(datos, archivo, indent=4, ensure_ascii=False)

def dinero(mensaje):
    while True:
        try:
            numero = float(input(mensaje))
            if numero >= 0:
                return numero
        except ValueError:
            pass
        print('Escribe un numero valido, mayor o igual a cero.')

def elegir_vehiculo(datos):
    if not datos['vehiculos']:
        print('Primero registra un vehiculo.')
        return None
    for vehiculo in datos['vehiculos']:
        print(vehiculo['placa'], '-', vehiculo['marca'], vehiculo['modelo'])
    placa = input('Placa del vehiculo: ').strip().upper()
    for vehiculo in datos['vehiculos']:
        if vehiculo['placa'] == placa:
            return vehiculo
    print('No se encontro esa placa.')
    return None

def registrar_vehiculo(datos):
    placa = input('Placa: ').strip().upper()
    if not placa or any(v['placa'] == placa for v in datos['vehiculos']):
        print('Placa vacia o ya registrada.')
        return
    marca = input('Marca: ').strip()
    modelo = input('Modelo: ').strip()
    anio = input('Año: ').strip()
    km = dinero('Kilometraje actual: ')
    datos['vehiculos'].append({'placa': placa, 'marca': marca, 'modelo': modelo, 'anio': anio, 'km': km})
    guardar(datos)
    print('Vehiculo guardado.')

def registrar_gasto(datos):
    vehiculo = elegir_vehiculo(datos)
    if vehiculo is None:
        return
    print('\nCategorias de gastos:')
    for numero, (nombre, tipo) in CATEGORIAS.items():
        print(numero + '.', nombre, '(' + tipo + ')')
    opcion = input('Elige una categoria: ').strip()
    if opcion not in CATEGORIAS:
        print('Categoria no valida.')
        return
    nombre, tipo = CATEGORIAS[opcion]
    monto = dinero('Monto en RD$: ')
    fecha = input('Fecha (AAAA-MM-DD, Enter para hoy): ').strip() or str(date.today())
    try:
        date.fromisoformat(fecha)
    except ValueError:
        print('Fecha incorrecta.')
        return
    descripcion = input('Descripcion del gasto: ').strip()
    # Cada gasto se registra una sola vez, por su fecha de pago.
    nuevo = {'id': max([g['id'] for g in datos['gastos']], default=0) + 1,
             'placa': vehiculo['placa'], 'categoria': nombre, 'tipo': tipo,
             'monto': monto, 'fecha': fecha, 'descripcion': descripcion}
    datos['gastos'].append(nuevo)
    guardar(datos)
    print('Gasto guardado con ID', nuevo['id'])

def mostrar_gastos(datos):
    vehiculo = elegir_vehiculo(datos)
    if vehiculo is None:
        return
    encontrados = [g for g in datos['gastos'] if g['placa'] == vehiculo['placa']]
    if not encontrados:
        print('Todavia no hay gastos.')
    for gasto in encontrados:
        print('ID:', gasto['id'], '|', gasto['fecha'], '|', gasto['categoria'],
              '| RD$', format(gasto['monto'], '.2f'), '|', gasto['descripcion'])

def eliminar_gasto(datos):
    mostrar_gastos(datos)
    try:
        numero = int(input('ID del gasto que deseas eliminar: '))
    except ValueError:
        print('ID incorrecto.')
        return
    for gasto in datos['gastos']:
        if gasto['id'] == numero:
            confirmar = input('¿Eliminar este gasto? (s/n): ').lower()
            if confirmar == 's':
                datos['gastos'].remove(gasto)
                guardar(datos)
                print('Gasto eliminado.')
            return
    print('No existe ese gasto.')

def editar_gasto(datos):
    vehiculo = elegir_vehiculo(datos)
    if vehiculo is None:
        return
    try:
        numero = int(input('ID del gasto que deseas editar: '))
    except ValueError:
        print('ID incorrecto.')
        return
    for gasto in datos['gastos']:
        if gasto['id'] == numero and gasto['placa'] == vehiculo['placa']:
            gasto['monto'] = dinero('Nuevo monto en RD$: ')
            gasto['descripcion'] = input('Nueva descripcion: ').strip()
            guardar(datos)
            print('Gasto actualizado.')
            return
    print('No existe ese gasto para este vehiculo.')

def reporte(datos):
    vehiculo = elegir_vehiculo(datos)
    if vehiculo is None:
        return
    mes = input('Mes a consultar (AAAA-MM): ').strip()
    try:
        anio, numero_mes = mes.split('-')
        if len(anio) != 4 or len(numero_mes) != 2 or not 1 <= int(numero_mes) <= 12:
            raise ValueError
        int(anio)
    except ValueError:
        print('Formato incorrecto. Ejemplo: 2026-11')
        return
    fijos = 0
    variables = 0
    for gasto in datos['gastos']:
        if gasto['placa'] == vehiculo['placa'] and gasto['fecha'].startswith(mes + '-'):
            if gasto['tipo'] == 'Fijo':
                fijos += gasto['monto']
            else:
                variables += gasto['monto']
    print('\n--- REPORTE DE', mes, '---')
    print('Vehiculo:', vehiculo['placa'])
    print('Gastos fijos pagados: RD$', format(fijos, '.2f'))
    print('Gastos variables pagados: RD$', format(variables, '.2f'))
    print('Total del mes: RD$', format(fijos + variables, '.2f'))
    print('Nota: se muestran pagos registrados, no estimaciones de otros meses.')

def reporte_anual(datos):
    vehiculo = elegir_vehiculo(datos)
    if vehiculo is None:
        return
    anio = input('Año a consultar (AAAA): ').strip()
    if len(anio) != 4 or not anio.isdigit():
        print('Año incorrecto.')
        return
    total = 0
    for gasto in datos['gastos']:
        if gasto['placa'] == vehiculo['placa'] and gasto['fecha'].startswith(anio + '-'):
            total += gasto['monto']
    print('Total pagado en', anio, ': RD$', format(total, '.2f'))
    km = dinero('Kilometros recorridos durante ese año (0 si no sabes): ')
    if km > 0:
        print('Costo registrado por kilometro: RD$', format(total / km, '.2f'))

def main():
    datos = cargar()
    while True:
        print('\n=== GESTION DE COSTOS DE VEHICULOS ===')
        print('1. Registrar vehiculo')
        print('2. Registrar gasto')
        print('3. Ver gastos')
        print('4. Editar gasto')
        print('5. Eliminar gasto')
        print('6. Reporte mensual')
        print('7. Reporte anual y costo por kilometro')
        print('8. Salir')
        opcion = input('Elige una opcion: ').strip()
        if opcion == '1': registrar_vehiculo(datos)
        elif opcion == '2': registrar_gasto(datos)
        elif opcion == '3': mostrar_gastos(datos)
        elif opcion == '4': editar_gasto(datos)
        elif opcion == '5': eliminar_gasto(datos)
        elif opcion == '6': reporte(datos)
        elif opcion == '7': reporte_anual(datos)
        elif opcion == '8':
            print('Hasta luego.')
            break
        else: print('Opcion no valida.')

if __name__ == '__main__':
    main()
