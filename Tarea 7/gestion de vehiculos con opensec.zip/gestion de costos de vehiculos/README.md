# gestion de costos de vehiculos

Programa de consola en Python 3. Usa `if`, `while`, `for`, funciones, listas y diccionarios.

## Ejecutar

1. Instala Python 3.
2. Abre la terminal dentro de esta carpeta.
3. Ejecuta `python programa.py` (o `py programa.py` en Windows).
4. Usa el menú para registrar un vehículo y sus gastos.

Los datos se guardan automáticamente en `datos.json`.

## Notas

- Los reportes muestran pagos registrados por fecha. No se generan pagos futuros automáticamente.
- La depreciación se introduce manualmente como estimación. Si se registra, se suma como costo económico y no como salida de efectivo.
- Las cuotas de préstamos se suman como pagos de caja. No debe interpretarse el total como costo económico puro porque una parte de la cuota amortiza capital.
- El costo por kilómetro utiliza la distancia anual indicada por el usuario.
