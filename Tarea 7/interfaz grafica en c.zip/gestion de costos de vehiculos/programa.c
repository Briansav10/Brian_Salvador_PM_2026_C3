#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <string.h>

#define MAX_GASTOS 1000
#define ID_AGREGAR 101
#define ID_ELIMINAR 102
#define ID_GUARDAR 103
#define ID_CATEGORIA 104
#define ID_MONTO 105
#define ID_LISTA 106
#define ID_VEHICULO 107

typedef struct {
    int categoria;
    double monto;
} Gasto;

const wchar_t *categorias[] = {
    L"Seguro", L"Marbete", L"Revista vehicular", L"Prestamo del vehiculo",
    L"Depreciacion", L"Impuestos y permisos", L"Parqueo mensual",
    L"Combustible", L"Mantenimiento por uso", L"Neumaticos", L"Aceite",
    L"Reparaciones", L"Estacionamiento por horas", L"Lavado"
};
Gasto gastos[MAX_GASTOS];
int cantidad = 0;
HWND ventana, combo, monto, lista, totalFijo, totalVariable, totalGeneral, vehiculo;

void actualizar() {
    int i;
    double fijo = 0, variable = 0;
    wchar_t texto[200];
    SendMessage(lista, LB_RESETCONTENT, 0, 0);
    for (i = 0; i < cantidad; i++) {
        swprintf(texto, 200, L"%d. %ls - RD$ %.2f", i + 1, categorias[gastos[i].categoria], gastos[i].monto);
        SendMessage(lista, LB_ADDSTRING, 0, (LPARAM)texto);
        if (gastos[i].categoria < 7) fijo += gastos[i].monto;
        else variable += gastos[i].monto;
    }
    swprintf(texto, 200, L"Costos fijos: RD$ %.2f", fijo);
    SetWindowText(totalFijo, texto);
    swprintf(texto, 200, L"Costos variables: RD$ %.2f", variable);
    SetWindowText(totalVariable, texto);
    swprintf(texto, 200, L"Total registrado: RD$ %.2f", fijo + variable);
    SetWindowText(totalGeneral, texto);
}

void guardar() {
    FILE *archivo = fopen("gastos.txt", "w");
    int i;
    wchar_t nombre[100];
    if (!archivo) {
        MessageBox(ventana, L"No se pudo guardar el archivo.", L"Error", MB_OK | MB_ICONERROR);
        return;
    }
    GetWindowText(vehiculo, nombre, 100);
    fprintf(archivo, "Vehiculo: ");
    for (i = 0; nombre[i]; i++) fputc(nombre[i] < 128 ? (char)nombre[i] : '?', archivo);
    fprintf(archivo, "\n");
    for (i = 0; i < cantidad; i++) fprintf(archivo, "%d %.2f\n", gastos[i].categoria, gastos[i].monto);
    fclose(archivo);
    MessageBox(ventana, L"Datos guardados en gastos.txt", L"Guardado", MB_OK | MB_ICONINFORMATION);
}

void cargar() {
    FILE *archivo = fopen("gastos.txt", "r");
    char linea[256];
    int cat;
    double valor;
    if (!archivo) return;
    if (fgets(linea, sizeof(linea), archivo)) {
        wchar_t nombre[100];
        int i = 0;
        char *p = linea;
        if (strncmp(p, "Vehiculo: ", 10) == 0) p += 10;
        while (p[i] && p[i] != '\n' && i < 99) { nombre[i] = (unsigned char)p[i]; i++; }
        nombre[i] = 0;
        SetWindowText(vehiculo, nombre);
    }
    while (cantidad < MAX_GASTOS && fscanf(archivo, "%d %lf", &cat, &valor) == 2) {
        if (cat >= 0 && cat < 14 && valor >= 0) {
            gastos[cantidad].categoria = cat;
            gastos[cantidad].monto = valor;
            cantidad++;
        }
    }
    fclose(archivo);
    actualizar();
}

HWND etiqueta(const wchar_t *texto, int x, int y, int ancho, int alto) {
    return CreateWindow(L"STATIC", texto, WS_CHILD | WS_VISIBLE, x, y, ancho, alto, ventana, NULL, NULL, NULL);
}

LRESULT CALLBACK procedimiento(HWND hwnd, UINT mensaje, WPARAM wParam, LPARAM lParam) {
    switch (mensaje) {
        case WM_CREATE: {
            int i;
            ventana = hwnd;
            etiqueta(L"GESTION DE COSTOS DE VEHICULOS", 20, 15, 420, 28);
            etiqueta(L"Vehiculo (placa o modelo):", 20, 55, 200, 22);
            vehiculo = CreateWindowEx(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                220, 52, 280, 26, hwnd, (HMENU)ID_VEHICULO, NULL, NULL);
            etiqueta(L"Tipo de gasto:", 20, 100, 150, 22);
            combo = CreateWindow(L"COMBOBOX", L"", WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
                170, 96, 330, 260, hwnd, (HMENU)ID_CATEGORIA, NULL, NULL);
            for (i = 0; i < 14; i++) SendMessage(combo, CB_ADDSTRING, 0, (LPARAM)categorias[i]);
            SendMessage(combo, CB_SETCURSEL, 0, 0);
            etiqueta(L"Monto (RD$):", 20, 145, 150, 22);
            monto = CreateWindowEx(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                170, 140, 180, 28, hwnd, (HMENU)ID_MONTO, NULL, NULL);
            CreateWindow(L"BUTTON", L"Agregar gasto", WS_CHILD | WS_VISIBLE,
                365, 140, 135, 30, hwnd, (HMENU)ID_AGREGAR, NULL, NULL);
            etiqueta(L"Gastos registrados:", 20, 188, 230, 22);
            lista = CreateWindowEx(WS_EX_CLIENTEDGE, L"LISTBOX", L"", WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOTIFY,
                20, 215, 480, 200, hwnd, (HMENU)ID_LISTA, NULL, NULL);
            CreateWindow(L"BUTTON", L"Eliminar seleccionado", WS_CHILD | WS_VISIBLE,
                20, 430, 190, 32, hwnd, (HMENU)ID_ELIMINAR, NULL, NULL);
            CreateWindow(L"BUTTON", L"Guardar datos", WS_CHILD | WS_VISIBLE,
                320, 430, 180, 32, hwnd, (HMENU)ID_GUARDAR, NULL, NULL);
            totalFijo = etiqueta(L"Costos fijos: RD$ 0.00", 20, 480, 480, 22);
            totalVariable = etiqueta(L"Costos variables: RD$ 0.00", 20, 507, 480, 22);
            totalGeneral = etiqueta(L"Total registrado: RD$ 0.00", 20, 534, 480, 22);
            etiqueta(L"Nota: se suman los montos registrados, sin convertir periodos.", 20, 572, 500, 22);
            cargar();
            return 0;
        }
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case ID_AGREGAR: {
                    wchar_t texto[100], *fin;
                    double valor;
                    int cat;
                    if (cantidad >= MAX_GASTOS) {
                        MessageBox(hwnd, L"Limite de gastos alcanzado.", L"Aviso", MB_OK);
                        break;
                    }
                    GetWindowText(monto, texto, 100);
                    valor = wcstod(texto, &fin);
                    while (*fin == L' ') fin++;
                    if (fin == texto || *fin != 0 || valor <= 0 || valor > 1000000000) {
                        MessageBox(hwnd, L"Escribe un monto valido mayor que cero. Usa punto para decimales.", L"Error", MB_OK | MB_ICONWARNING);
                        break;
                    }
                    cat = (int)SendMessage(combo, CB_GETCURSEL, 0, 0);
                    if (cat < 0) break;
                    gastos[cantidad].categoria = cat;
                    gastos[cantidad].monto = valor;
                    cantidad++;
                    SetWindowText(monto, L"");
                    actualizar();
                    break;
                }
                case ID_ELIMINAR: {
                    int i, seleccionado = (int)SendMessage(lista, LB_GETCURSEL, 0, 0);
                    if (seleccionado == LB_ERR) {
                        MessageBox(hwnd, L"Selecciona un gasto de la lista.", L"Aviso", MB_OK);
                        break;
                    }
                    for (i = seleccionado; i < cantidad - 1; i++) gastos[i] = gastos[i + 1];
                    cantidad--;
                    actualizar();
                    break;
                }
                case ID_GUARDAR: guardar(); break;
            }
            return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProc(hwnd, mensaje, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE instancia, HINSTANCE anterior, PWSTR comando, int mostrar) {
    WNDCLASS clase = {0};
    HWND hwnd;
    MSG mensaje;
    clase.lpfnWndProc = procedimiento;
    clase.hInstance = instancia;
    clase.lpszClassName = L"CostosVehiculos";
    clase.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    clase.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&clase);
    hwnd = CreateWindow(clase.lpszClassName, L"Gestion de costos de vehiculos",
        WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 540, 660, NULL, NULL, instancia, NULL);
    if (!hwnd) return 0;
    ShowWindow(hwnd, mostrar);
    while (GetMessage(&mensaje, NULL, 0, 0)) {
        TranslateMessage(&mensaje);
        DispatchMessage(&mensaje);
    }
    return 0;
}
