GESTION DE COSTOS DE VEHICULOS

Proyecto basico de programacion en Python, sin OpenSpec y sin librerias externas.

COMO EJECUTAR
1. Instala Python 3 si aun no lo tienes.
2. Abre la carpeta del proyecto en la terminal.
3. Escribe: python programa.py
4. Usa el menu para registrar y consultar gastos.

Los datos se guardan automaticamente en gastos.json, que se crea al registrar el primer gasto.

El programa clasifica 14 tipos de gastos en fijos y variables.
El resumen suma los gastos registrados, sin repetir automaticamente pagos anuales o mensuales.
