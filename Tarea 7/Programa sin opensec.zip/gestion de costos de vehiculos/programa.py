import json
import os
from datetime import datetime

ARCHIVO = 'gastos.json'

categorias = {
    '1': ('Seguro', 'Fijo'),
    '2': ('Marbete', 'Fijo'),
    '3': ('Revista vehicular', 'Fijo'),
    '4': ('Prestamo del vehiculo', 'Fijo'),
    '5': ('Depreciacion', 'Fijo'),
    '6': ('Impuestos y permisos', 'Fijo'),
    '7': ('Parqueo mensual', 'Fijo'),
    '8': ('Combustible', 'Variable'),
    '9': ('Mantenimiento por uso', 'Variable'),
    '10': ('Neumaticos', 'Variable'),
    '11': ('Aceite', 'Variable'),
    '12': ('Reparaciones', 'Variable'),
    '13': ('Estacionamiento por horas', 'Variable'),
    '14': ('Lavado', 'Variable')
}


def cargar_gastos():
    if os.path.exists(ARCHIVO):
        try:
            with open(ARCHIVO, 'r', encoding='utf-8') as archivo:
                return json.load(archivo)
        except (json.JSONDecodeError, OSError):
            print('No se pudo leer el archivo de gastos.')
    return []


def guardar_gastos(gastos):
    with open(ARCHIVO, 'w', encoding='utf-8') as archivo:
        json.dump(gastos, archivo, indent=4, ensure_ascii=False)


def pedir_monto():
    while True:
        try:
            monto = float(input('Monto en RD$: '))
            if monto >= 0:
                return monto
            print('El monto no puede ser negativo.')
        except ValueError:
            print('Escribe un numero valido.')


def pedir_fecha():
    while True:
        fecha = input('Fecha (AAAA-MM-DD), Enter para hoy: ').strip()
        if fecha == '':
            return datetime.now().strftime('%Y-%m-%d')
        try:
            datetime.strptime(fecha, '%Y-%m-%d')
            return fecha
        except ValueError:
            print('La fecha no es valida.')


def registrar(gastos):
    print('\n--- REGISTRAR GASTO ---')
    vehiculo = input('Nombre o placa del vehiculo: ').strip()
    if not vehiculo:
        print('Debes escribir un vehiculo.')
        return
    for numero, datos in categorias.items():
        print(numero + '. ' + datos[0])
    opcion = input('Elige la categoria: ').strip()
    if opcion not in categorias:
        print('Categoria incorrecta.')
        return
    monto = pedir_monto()
    fecha = pedir_fecha()
    descripcion = input('Descripcion (opcional): ')
    gasto = {
        'id': max([g['id'] for g in gastos], default=0) + 1,
        'vehiculo': vehiculo,
        'categoria': categorias[opcion][0],
        'tipo': categorias[opcion][1],
        'monto': monto,
        'fecha': fecha,
        'descripcion': descripcion
    }
    gastos.append(gasto)
    guardar_gastos(gastos)
    print('Gasto guardado correctamente.')


def mostrar(gastos):
    if not gastos:
        print('Todavia no hay gastos registrados.')
        return
    print('\n--- LISTA DE GASTOS ---')
    for g in gastos:
        print(f"ID: {g['id']} | {g['fecha']} | {g['vehiculo']} | {g['categoria']} | RD$ {g['monto']:.2f}")
        if g['descripcion']:
            print('   Detalle:', g['descripcion'])


def resumen(gastos):
    print('\n--- RESUMEN DE COSTOS ---')
    vehiculo = input('Placa o nombre (Enter para todos): ').strip().lower()
    mes = input('Mes AAAA-MM (Enter para todos): ').strip()
    seleccion = []
    for g in gastos:
        if vehiculo and vehiculo not in g['vehiculo'].lower():
            continue
        if mes and not g['fecha'].startswith(mes):
            continue
        seleccion.append(g)
    fijo = sum(g['monto'] for g in seleccion if g['tipo'] == 'Fijo')
    variable = sum(g['monto'] for g in seleccion if g['tipo'] == 'Variable')
    print(f'Costos fijos: RD$ {fijo:.2f}')
    print(f'Costos variables: RD$ {variable:.2f}')
    print(f'Total: RD$ {fijo + variable:.2f}')
    print('Nota: los totales suman gastos registrados; no proyectan pagos futuros.')


def eliminar(gastos):
    mostrar(gastos)
    if not gastos:
        return
    try:
        numero = int(input('ID del gasto que deseas eliminar: '))
    except ValueError:
        print('ID incorrecto.')
        return
    for g in gastos:
        if g['id'] == numero:
            if input('Confirmar eliminacion (s/n): ').lower() == 's':
                gastos.remove(g)
                guardar_gastos(gastos)
                print('Gasto eliminado.')
            return
    print('No se encontro ese ID.')


def editar(gastos):
    mostrar(gastos)
    if not gastos:
        return
    try:
        numero = int(input('ID del gasto que deseas editar: '))
    except ValueError:
        print('ID incorrecto.')
        return
    for g in gastos:
        if g['id'] == numero:
            print('Introduce el nuevo monto.')
            g['monto'] = pedir_monto()
            guardar_gastos(gastos)
            print('Gasto actualizado.')
            return
    print('No se encontro ese ID.')


def main():
    gastos = cargar_gastos()
    while True:
        print('\n===== GESTION DE COSTOS DE VEHICULOS =====')
        print('1. Registrar gasto')
        print('2. Ver gastos')
        print('3. Resumen de costos')
        print('4. Editar monto de un gasto')
        print('5. Eliminar gasto')
        print('6. Salir')
        opcion = input('Selecciona una opcion: ').strip()
        if opcion == '1':
            registrar(gastos)
        elif opcion == '2':
            mostrar(gastos)
        elif opcion == '3':
            resumen(gastos)
        elif opcion == '4':
            editar(gastos)
        elif opcion == '5':
            eliminar(gastos)
        elif opcion == '6':
            print('Hasta luego.')
            break
        else:
            print('Opcion no valida.')


if __name__ == '__main__':
    main()
